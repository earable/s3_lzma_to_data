import os
import requests
import pandas as pd
import socket
from cryptography.fernet import Fernet

# Function to check internet connectivity
def is_connected():
    try:
        # Connect to the host -- tells us if the host is actually reachable
        socket.create_connection(('8.8.8.8', 53), timeout=5)
        return True
    except OSError:
        return False
    

def validate_product_key(product_key: str) -> bool:
    """
    Validate the product key against the backend server.
    
    Args:
        product_key (str): The product key to validate
        
    Returns:
        bool: True if the product key is valid, False otherwise
        
    Raises:
        requests.RequestException: If there's an error connecting to the server
    """
        # Check for internet connectivity
    if not is_connected():
        print("No internet connection.")
        return False

    response = requests.get('https://earable-data-prod.s3.us-east-2.amazonaws.com/product_key/product_key.csv.enc')
    response.raise_for_status()  # Check for request errors
    encrypted_file_name = 'product_key.csv.enc'
    with open(encrypted_file_name, 'wb') as file:
        file.write(response.content)

    fernet = Fernet('BDruqouyY4RWmXc9dV-D-1iGMf9EVrMIXIUQqJ1LqCg=')
    
    # Read the encrypted file
    with open(encrypted_file_name, 'rb') as encrypted_file:
        encrypted = encrypted_file.read()
    
    # Decrypt the file
    decrypted = fernet.decrypt(encrypted)
    
    # Write the decrypted file
    output_file_name = 'product_key.csv'
    with open(output_file_name, 'wb') as decrypted_file:
        decrypted_file.write(decrypted)

    # Read the CSV file
    df = pd.read_csv(output_file_name)
    
    # Assuming the tokens are in the first column
    tokens = df.iloc[:, 0].tolist()

    # print(tokens)
    # Check if the token is valid
    is_valid = product_key in tokens

    # Delete the CSV file after checking
    os.remove(output_file_name)
    os.remove(encrypted_file_name)
    return is_valid
    
if __name__ == '__main__':
    print("Validating product key...")
    print(validate_product_key("dOR66P4E05y971ErJROq7SDR0XN3J2UJ8iMzWMUxVEM="))
