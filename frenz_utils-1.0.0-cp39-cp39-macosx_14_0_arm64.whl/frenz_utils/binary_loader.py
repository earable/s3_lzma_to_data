"""
Parsing raw signals from S3 data files as data format BLE protocol
"""

import numpy as np

def get_interpolation_flag(signature: int, n_bits: int, n_bits_needed: int):
    binary_array_str = np.binary_repr(signature, n_bits)
    binary_array_int = np.array([int(i) for i in binary_array_str])
    interpolation_flag = np.flip(binary_array_int)[:n_bits_needed]
    return interpolation_flag

def convert_string_to_int(str_bit):
    str_bit = str_bit[::-1]
    results = 0
    for i, bit_value in enumerate(str_bit):
        results += 2**i * int(bit_value)
    return results

# EEG PROCESSING —————————————————————————————————————————————————————————————————————————————————————————————————————————
def pop_str(text, num=1):
    "Pop a string"
    popped, remain = text[:num], text[num:]
    return popped, remain

def one_chunk_parser(chunk, byteorder="big"):
    remain_chunk = chunk
    chnls_data = []
    offset_data = []

    # [1 byte sequence number]
    sequence_number_binary, remain_chunk = pop_str(remain_chunk, 1)
    sequence_number = int.from_bytes(
        sequence_number_binary, byteorder=byteorder, signed=False)

    # [1 byte number of channel]
    number_of_channel_binary, remain_chunk = pop_str(remain_chunk, 1)
    number_of_channel = int.from_bytes(
        number_of_channel_binary, byteorder=byteorder, signed=False)
    if number_of_channel not in [4, 6]:
        print(f"Number of Channels is {number_of_channel}, not 4 or 6. This can be a dummy sample.")
        return None, None, None, None, None, None

    # [4 byte timestamp] [channel 1]
    timestamp_binary, remain_chunk = pop_str(remain_chunk, 4)
    timestamp = int.from_bytes(
        timestamp_binary, byteorder=byteorder, signed=False)

    # Read the first sample from the batch
    # 6 chnls' data
    chnls_binary, remain_chunk = pop_str(remain_chunk, number_of_channel*3)
    chnls_int = [int.from_bytes(chnls_binary[(
        3*i):(3*(i+1))], byteorder=byteorder, signed=True) for i in range(number_of_channel)]
    chnls_data.append(chnls_int)

    while len(remain_chunk) > 2:
        # offset data
        offset_binary, remain_chunk = pop_str(remain_chunk, 1)
        offset = int.from_bytes(
            offset_binary, byteorder=byteorder, signed=False)
        offset_data.append(offset)

        # 6 chnls' data
        chnls_binary, remain_chunk = pop_str(remain_chunk, number_of_channel*3)
        chnls_int = [int.from_bytes(chnls_binary[(
            3*i):(3*(i+1))], byteorder=byteorder, signed=True) for i in range(number_of_channel)]
        chnls_data.append(chnls_int)

    # signature interpolation
    signarute_binary, remain_chunk = pop_str(remain_chunk, 2)
    signature = int.from_bytes(
        signarute_binary, byteorder=byteorder, signed=False)
    return sequence_number, number_of_channel, timestamp, chnls_data, offset_data, signature


def create_list_sample_eeg2(file):
    with open("{}".format(file), "rb") as f:
        remain_content = f.read()
    # remain_content = content
    sequence_numbers, number_of_channels, timestamps, chnls_data_list, offset_data_list, signatures = [], [], [], [], [], []
    interpolated_flags = []

    while len(remain_content) > 0:
        # Pop a chunk
        chunk, remain_content = pop_str(remain_content, 178)

        # Parsing a chunk
        sequence_number, number_of_channel, timestamp, chnls_data, offset_data, signature = one_chunk_parser(chunk)
        if sequence_number is None:
            continue

        sequence_numbers.append(sequence_number)
        number_of_channels.append(number_of_channel)
        timestamps.append([timestamp] + [timestamp+offset for offset in offset_data])
        chnls_data_list.append(np.array(chnls_data))
        offset_data_list.append(np.array(offset_data))
        interpolated_flags.append( get_interpolation_flag(signature, 16, 9))
        signatures.append(signature)

        if len(chnls_data_list) != len(interpolated_flags):
            pass

    if len(sequence_numbers) > 0:
        sort_data = []
        for i, (seq_num, ts_list) in enumerate(zip(sequence_numbers, timestamps)):
            base_timestamp = ts_list[0]
            sort_data.append((base_timestamp, seq_num, i))
        
        sort_data.sort(key=lambda x: (x[0], x[1]))
        
        sorted_indices = [item[2] for item in sort_data]
        
        sequence_numbers = [sequence_numbers[i] for i in sorted_indices]
        number_of_channels = [number_of_channels[i] for i in sorted_indices]
        timestamps = [timestamps[i] for i in sorted_indices]
        chnls_data_list = [chnls_data_list[i] for i in sorted_indices]
        offset_data_list = [offset_data_list[i] for i in sorted_indices]
        signatures = [signatures[i] for i in sorted_indices]
        interpolated_flags = [interpolated_flags[i] for i in sorted_indices]

    time_start, time_end = timestamps[0][0], timestamps[-1][-1]

    ts = np.expand_dims( np.reshape(np.array(timestamps), -1), -1 )
    raw_signals = np.array(chnls_data_list).reshape(-1, 6)
    interpolated_by_samples = np.expand_dims( np.reshape(np.array(interpolated_flags), -1), -1 )
    sequence_number_by_samples = np.expand_dims(np.repeat(np.array(sequence_numbers),9) , -1)
    return np.concatenate([ts, raw_signals, sequence_number_by_samples, interpolated_by_samples], axis=1), None, time_start, time_end


# SPO2 PROCESSER —————————————————————————————————————————————————————————————————————————————————————————————————————————
def create_list_sample_spo2(file):
    list_sample = []
    list_interpolation = []
    
    with open("{}".format(file), "rb") as f:
        file_content = f.read()
    # Get start and end timestamps from first and last samples
    time_start = int.from_bytes(file_content[:4], byteorder='big', signed=False)
    time_end = int.from_bytes(file_content[-4:], byteorder='big', signed=False)
    
    # Process each 6-byte sample
    index = 0
    while index < len(file_content):
        # Read timestamp (4 bytes)
        timestamp = int.from_bytes(file_content[index:index+4], byteorder='big', signed=False)
        # print("timestamp: ", timestamp)
        index += 4
        
        # Read SPO2 value (1 byte)
        spo2 = int.from_bytes(file_content[index:index+1], byteorder='big', signed=False)
        # print("spo2: ", spo2)
        index += 1
        
        # Read interpolation flag (1 byte)
        interpolation = int.from_bytes(file_content[index:index+1], byteorder='big', signed=False)
        index += 1
        
        list_sample.append([spo2, timestamp])
        list_interpolation.append(interpolation)
    return list_sample, list_interpolation, time_start, time_end

# HR PROCESSER —————————————————————————————————————————————————————————————————————————————————————————————————————————
def create_list_sample_hr(file):
    list_sample = []
    list_interpolation = []
    
    with open("{}".format(file), "rb") as f:
        file_content = f.read()
    
    # Get start and end timestamps from first and last samples
    time_start = int.from_bytes(file_content[:4], byteorder='big', signed=False)
    time_end = int.from_bytes(file_content[-4:], byteorder='big', signed=False)
    
    # Process each 6-byte sample
    index = 0
    while index < len(file_content):
        # Read timestamp (4 bytes)
        timestamp = int.from_bytes(file_content[index:index+4], byteorder='big', signed=False)
        index += 4
        
        # Read HR value (1 byte)
        hr = int.from_bytes(file_content[index:index+1], byteorder='big', signed=False)
        # print("hr: ", hr)
        index += 1
        
        # Read interpolation flag (1 byte)
        interpolation = int.from_bytes(file_content[index:index+1], byteorder='big', signed=False)
        index += 1
        list_sample.append([hr, timestamp])
        list_interpolation.append(interpolation)
    # print("list_sample HR: ", list_sample)
    return list_sample, list_interpolation, time_start, time_end

# IMU PROCESSER —————————————————————————————————————————————————————————————————————————————————————————————————————————
def create_list_sample_imu2(file):
    with open("{}".format(file), "rb") as f:
       file_content = f.read()
    
    idx = 0
    list_samples = []
    list_timestamp = []
    list_signature = []
    interpolated_flags = []

    while idx < len(file_content):
        t = int.from_bytes(file_content[idx:idx + 4],byteorder="big",signed=False)
        if len(list_timestamp) != 0 and abs(t - list_timestamp[-1]) > 3600*24*100:
            print(f"Error when retrieving timestamp in file {file}")
            print(f"Check if the data is interpolated from the previous epoch, increase timestamp by one second")
            x = int.from_bytes(file_content[idx:idx + 2],byteorder="big",signed=True)
            y = int.from_bytes(file_content[idx + 2:idx + 4],byteorder="big",signed=True)
            z = int.from_bytes(file_content[idx + 4:idx + 6],byteorder="big",signed=True)
            if x == list_samples[-1][1] and y == list_samples[-1][2] and z == list_samples[-1][3]:
                print(f"Data is interpolated, increase timestamp by one second")
                list_timestamp.append(list_timestamp[-1] + 1)
            else:
                raise Exception("Error unhandled")
        else:
            list_timestamp.append(t)
            idx += 4
        scaling_factor=1.0
        for i in range(25):
            sample = []
            sample.append(i)
            for _ in range(3):
                sample.append(
                    int.from_bytes(file_content[idx:idx + 2],
                                  byteorder="big",
                                  signed=True)*scaling_factor)
                idx += 2
            list_samples.append(sample)
        signature = int.from_bytes(file_content[idx:idx + 4],
                                  byteorder="big",
                                  signed=True)
        list_signature.append(signature)
        interpolated_flags.append( get_interpolation_flag(signature, 32, 25))
        idx += 4

    raw_signals = np.array(list_samples)[:,1:]
    ts_full = np.expand_dims( np.repeat(list_timestamp, 25), -1)
    interpolated_by_samples = np.expand_dims( np.reshape(np.array(interpolated_flags), -1), -1 )
    return np.concatenate([ts_full, raw_signals, interpolated_by_samples], axis=1), None, list_timestamp[0], list_timestamp[-1]


# PPG PROCESSOR —————————————————————————————————————————————————————————————————————————————————————————————————————————
def create_list_sample_ppg2(file):
    with open("{}".format(file), "rb") as f:
       file_content = f.read()
    
    idx = 0
    list_timestamp = []
    list_samples = []
    list_samples_with_ts = []
    list_signature = []
    list_package_ind = []
    list_interpolated_flags = []
    while idx < len(file_content):
        size = int.from_bytes(file_content[idx:idx+1],
                byteorder="big",
                signed=False) - 4
        idx += 1
        timestamp = int.from_bytes(file_content[idx:idx+4],
                byteorder="big",
                signed=False)
        list_timestamp.append(timestamp)
        idx += 4
        sample_num = 0
        for sample_idx in range(int(size/9)):
            if size < 9:
                print(f"Warning: Invalid size {size} for PPG data. Expected at least 9 bytes.")
                break
            sample = []
            sample.append(sample_idx)
            for i in range(3):
                sample.append(int.from_bytes(file_content[idx:idx+3],
                    byteorder="big",
                    signed=False) & 0x7ffff)
                idx += 3
                size -= 3
            sample_num += 1
            list_samples.append(sample)
            list_samples_with_ts.append([ timestamp ] + sample[1:])
        if sample_num == 12:
            package_ind = 0
        elif sample_num == 13:
            package_ind = 1
        else:
            print("PACKAGE SIZE ERROR: PPG sample num = ", sample_num)
            raise ValueError(f"Invalid PPG package size: {sample_num}. Expected 12 or 13 samples.")
        list_package_ind.append([package_ind]*sample_num)
        signature = int.from_bytes(file_content[idx:idx+size],
                    byteorder="big",
                    signed=False)
        list_signature.append(signature)
        list_interpolated_flags.append( get_interpolation_flag(signature, 16, sample_idx+1))
        idx += size

    data_values = np.array(list_samples_with_ts)
    package_index_by_samples = np.expand_dims(np.array([i for l in list_package_ind for i in l]), -1)
    interpolated_by_samples = np.expand_dims(np.concatenate(list_interpolated_flags), -1)
    arr = np.concatenate([ data_values, interpolated_by_samples], axis=1)
    return arr, None, list_timestamp[0], list_timestamp[-1]