#!/usr/bin/env python3
"""
Script to convert JSON to CSV
CSV filename: sessionId + "_" + __name__
Data: 2 columns - timestamp and value from values array
"""

import json
import csv
import sys
import os
import glob
from pathlib import Path
try:
    from .backend_connector import validate_product_key
except ImportError:
    try:
        from backend_connector import validate_product_key
    except ImportError:
        from frenz_utils.backend_connector import validate_product_key


class JsonToCsvConverter:
    def __init__(self, product_key):
        """
        Initialize JsonToCsvConverter with product key validation
        
        Args:
            product_key (str): Product key to validate before processing
            
        Raises:
            ValueError: If product key is invalid
        """
        self.product_key = product_key
        
        # Validate product key before proceeding
        print("🔐 Validating product key...")
        if not validate_product_key(product_key):
            raise ValueError("❌ Invalid product key. Please check your product key and try again.")
        print("✅ Product key validated successfully!")
    
    def convert_json_to_csv(self, json_file_path):
        """
        Convert JSON file to CSV
        
        Args:
            json_file_path (str): Path to JSON file
        
        Returns:
            str: Path to created CSV file
        """
        try:
            # Read JSON file
            with open(json_file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
            
            # Check JSON structure
            if 'data' not in data or 'result' not in data['data']:
                raise ValueError("Invalid JSON structure: missing 'data' or 'result'")
            
            result = data['data']['result']
            if not result or len(result) == 0:
                raise ValueError("No data in 'result'")
            
            # Get information from first object
            first_result = result[0]
            metric = first_result.get('metric', {})
            values = first_result.get('values', [])
            
            # Get sessionId and __name__ to create filename
            session_id = metric.get('sessionId', 'unknown_session')
            metric_name = metric.get('__name__', 'unknown_metric')
            
            # Create CSV filename
            csv_filename = f"{session_id}_{metric_name}.csv"
            
            # Create full path for CSV file
            json_path = Path(json_file_path)
            csv_path = json_path.parent / csv_filename
            
            # Write data to CSV file
            with open(csv_path, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                
                # Write header
                writer.writerow(['timestamp', 'value'])
                
                # Write data from values
                for value_pair in values:
                    if len(value_pair) >= 2:
                        timestamp = value_pair[0]
                        value = value_pair[1]
                        writer.writerow([timestamp, value])
            
            print(f"✅ Converted successfully!")
            print(f"📁 JSON file: {json_file_path}")
            print(f"📄 CSV file: {csv_path}")
            print(f"📊 Number of data rows: {len(values)}")
            
            return str(csv_path)
            
        except FileNotFoundError:
            print(f"❌ Error: File not found {json_file_path}")
            return None
        except json.JSONDecodeError as e:
            print(f"❌ Error: Invalid JSON file - {e}")
            return None
        except Exception as e:
            print(f"❌ Error: {e}")
            return None
    
    def convert_multiple_files(self, json_files):
        """
        Convert multiple JSON files to CSV
        
        Args:
            json_files (list): List of JSON file paths
        
        Returns:
            dict: Dictionary with file paths as keys and conversion results as values
        """
        results = {}
        success_count = 0
        
        print(f"🔄 Converting {len(json_files)} JSON files...")
        
        for json_file in json_files:
            print(f"\n📄 Processing: {json_file}")
            result = self.convert_json_to_csv(json_file)
            results[json_file] = result
            
            if result:
                success_count += 1
        
        print(f"\n📊 Conversion Summary:")
        print(f"✅ Successfully converted: {success_count}/{len(json_files)} files")
        
        return results


def convert_json_to_csv(json_file_path):
    """
    Legacy function for backward compatibility
    """
    print("⚠️  Warning: Using legacy function without product key validation")
    print("💡 Consider using JsonToCsvConverter class instead")
    
    converter = JsonToCsvConverter("dOR66P4E05y971ErJROq7SDR0XN3J2UJ8iMzWMUxVEM=")
    return converter.convert_json_to_csv(json_file_path)


def find_json_files():
    """
    Find all JSON files in current directory
    
    Returns:
        list: List of JSON file paths
    """
    json_files = glob.glob("*.json")
    return json_files


 