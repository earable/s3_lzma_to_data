"""
Frenz Utils Package
==================

A comprehensive utility package for processing and analyzing Frenz wearable device data.

Modules:
--------
- backend_connector: Product key validation and backend connectivity
- binary_loader: Raw signal parsing from binary data files
- data_loader: Data loading and processing utilities
- json_to_csv_converter: JSON to CSV conversion utilities
- process_and_save_data: Complete data processing workflow

Version: 1.0.0
"""

__version__ = "1.0.0"
__author__ = "Frenz Team"

# Import main modules
try:
    from . import backend_connector
    from . import binary_loader
    from . import data_loader
    from . import json_to_csv_converter
    from . import process_and_save_data
except ImportError:
    # Fallback for development - try absolute imports
    try:
        import backend_connector
        import binary_loader
        import data_loader
        import json_to_csv_converter
        import process_and_save_data
    except ImportError:
        # If still failing, try importing from frenz_utils package
        from frenz_utils import backend_connector, binary_loader, data_loader, json_to_csv_converter, process_and_save_data

# Export main classes and functions
__all__ = [
    'backend_connector',
    'binary_loader', 
    'data_loader',
    'json_to_csv_converter',
    'process_and_save_data',
] 