"""

Utility functions for:
  Convert .lzma file to binary file
  Parsing data from binary to numpy array
  Merge data from files of binary to one final array
"""

import os
import lzma
import pathlib
import numpy as np
import pandas as pd
from glob import glob
from datetime import datetime

try:
    from .binary_loader import  create_list_sample_eeg2, create_list_sample_imu2, create_list_sample_ppg2, create_list_sample_spo2, create_list_sample_hr
except ImportError:
    try:
        from binary_loader import  create_list_sample_eeg2, create_list_sample_imu2, create_list_sample_ppg2, create_list_sample_spo2, create_list_sample_hr
    except ImportError:
        from frenz_utils.binary_loader import  create_list_sample_eeg2, create_list_sample_imu2, create_list_sample_ppg2, create_list_sample_spo2, create_list_sample_hr

# Loading/ extracting lzma files
def lzma_to_binary(filename, extract_dir):
    "Read lzma file from lzma compressed file"
    contents = lzma.open(filename=filename).read()
    with open(extract_dir, "wb") as binary_file:
        binary_file.write(contents)


def get_load_func(folder, sensor):
  """
  Switch the load function and bucket
  """
  if sensor =='eeg':
    # If the folder path end with EEG2 => use the new parsing func
    if str(folder).replace("\\", "")[-4:]=="EEG2":
      load_func = create_list_sample_eeg2
    else:
        raise Exception("Unrecognize folder path (must be ended as EEG2): ", folder)
        
  elif sensor =='imu':
    if str(folder).replace("\\", "")[-4:]=="IMU2":
        load_func = create_list_sample_imu2
    else:
        raise Exception("Unrecognize folder path (must be ended as IMU2): ", folder)
    
  elif sensor =='ppg':
    if str(folder).replace("\\", "")[-4:]=="PPG2":
      load_func = create_list_sample_ppg2
    else:
        raise Exception("Unrecognize folder path (must be ended as PPG2): ", folder)
  elif sensor =='spo2':
    load_func = create_list_sample_spo2
  elif sensor =='hr':
    load_func = create_list_sample_hr
  else:
    raise Exception("Unrecognize sensor (must be ppg/eeg/imu): ", sensor)
  
  return load_func

def merge_raw_data(files):
  # files = glob(data_folder+'/*')
  # files = [file for file in files if os.path.isfile(file) and not file.endswith('merged.dat')]
  data_folder = os.path.dirname(files[0])
  p_data_dir = os.path.dirname(data_folder)
  out_f = os.path.join(p_data_dir, f"{os.path.basename(p_data_dir)}_{os.path.basename(data_folder)}_merged.dat")
  out_w = open(out_f, "wb")
  for file in files:
    f_r = open(file, "rb")
    data = f_r.read()
    out_w.write(data)
  out_w.close()
  print("Merged file: %s"%out_f)
  return out_f


def get_list_data_array(folder, start_file=0, file_num=None, sensor='eeg', return_files=False):
    load_func = get_load_func(folder, sensor)
    files = glob(folder+'/*')

    if file_num is not None:
      files = sorted(files)[start_file:(start_file+file_num)]

    list_samples, list_offsets, time_starts, time_ends = [], [], [], []
    for file in files:
        list_sample, list_offset, time_start, time_end = load_func(file)
        if len(list_sample) > 0:
          list_samples.append(list_sample)
          list_offsets.append(list_offset)
          time_starts.append(time_start)
          time_ends.append(time_end)
    if return_files:
      return list_samples, list_offsets, time_starts, time_ends, files
    
    return list_samples, list_offsets, time_starts, time_ends


def load_array_from_folder(local_folder=None, sensor='eeg', is_return_timestamp=False, verbose=True, return_file_start_times=False):
  """
  Reading local data to numpy array
  ===
  Params
    : sensor: str: "eeg" for EEG, "imu" for IMU, "ppg" for PPG
    : is_return_timestamp: bool: if True, return start timestamp of the session
  Return
    if is_return_timestamp: return a numpy array
    if not is_return_timestamp: return (arr, start_time)

  """
  file_num = 1
  if file_num > 0:
    list_samples, timeslots, time_starts, time_ends, files = get_list_data_array(
        local_folder, sensor=sensor, return_files=True)

    if verbose:
      for ts in sorted(zip(time_starts, time_ends)):
          print(datetime.fromtimestamp(ts[0]))

    arr = np.array([])
    if len(list_samples) > 0:
      if timeslots and timeslots[0] is not None:
        # When the data has 4-channels format, we must sort the array by timestamp and timeslot
        arr = np.concatenate([np.concatenate(list_samples), np.concatenate(timeslots).reshape(-1,1)], axis=1)
        arr = pd.DataFrame(arr).sort_values(by = [0,arr.shape[1]-1])
        arr = arr[arr[arr.shape[1]-1] != 127].values[:,list(range(arr.shape[1]-1))]
      else:
        # For HR and SPO2, we need to add timestamps manually
        if sensor in ['hr', 'spo2']:
            # Create timestamps for each sample
            all_samples = []
            all_timestamps = []
            for i, (time_start, samples) in enumerate(zip(time_starts, list_samples)):
                # Create timestamps for this file's samples
                n_samples = len(samples)
                if n_samples > 0:
                    # Create evenly spaced timestamps within the file's time range
                    timestamps = np.linspace(time_start, time_start + 1, n_samples)  # Assume 1 second per file
                    all_samples.extend(samples)
                    all_timestamps.extend(timestamps)
            
            if all_samples:
                # Combine samples with timestamps
                arr = np.column_stack([all_samples, all_timestamps])
        else:
            # For other sensors, use the original logic
            sort_list_arr= [x for _, x in sorted(zip(time_starts, list_samples))]
            arr = np.concatenate(sort_list_arr)

    if is_return_timestamp:
      return arr, min(time_starts)
    if return_file_start_times:
      return arr, files, time_starts
    else:
      return arr
  else:
    return np.array([])

def process_local_lzma_files(source_folder):
  """
  Process .lzma files from a local folder and extract them to a target folder
  Target folder is automatically created based on source folder name
  
  Args:
    source_folder: str - Path to source folder containing .lzma files
  
  Returns:
    str - Path to target folder where files were extracted
  """
  # Check if source folder exists
  if not os.path.exists(source_folder):
    raise FileNotFoundError(f"Source folder does not exist: {source_folder}")
  
  # Create target folder based on source folder name
  source_folder_name = os.path.basename(source_folder)
  target_folder = f"./extracted_{source_folder_name}"
  
  # Create target folder if it doesn't exist
  if not os.path.exists(target_folder):
    os.makedirs(target_folder)
  
  # Get all .lzma files from source folder
  file_list = []
  for root, dirs, files in os.walk(source_folder):
    for file in files:
      if file.endswith('.lzma'):
        file_path = os.path.join(root, file)
        file_list.append(file_path)
  
  # Sort files
  file_list = sorted(file_list)
  
  processed_count = 0
  
  for file_path in file_list:
    file_name = os.path.basename(file_path)
    file_stem = pathlib.Path(file_name).stem
    
    # Create subfolder structure in target folder
    relative_path = os.path.relpath(file_path, source_folder)
    relative_dir = os.path.dirname(relative_path)
    target_subfolder = os.path.join(target_folder, relative_dir)
    
    if not os.path.exists(target_subfolder):
      os.makedirs(target_subfolder)
    
    # Extract .lzma file
    target_file_path = os.path.join(target_subfolder, file_stem)
    
    try:
      lzma_to_binary(file_path, target_file_path)
      processed_count += 1
      print(f"Processed file: {file_name} from {file_path} to {target_file_path}")
        
    except Exception as e:
      print(f"Error processing file {file_name}: {str(e)}")
  
  print(f"Completed processing {processed_count} files from {source_folder} to {target_folder}")
  
  return target_folder

def process_and_load_data(source_folder, sensor='eeg'):
  """
  Complete workflow: Extract .lzma files and load data into numpy arrays
  
  Args:
    source_folder: str - Path to source folder containing .lzma files
    sensor: str - Type of sensor data ("eeg", "imu", "ppg", "hr", "spo2")
  
  Returns:
    tuple - (data_array, start_time, target_folder)
  """
  print(f"🔄 Starting complete workflow for sensor: {sensor}")
  print(f"📁 Source folder: {source_folder}")
  
  # Step 1: Extract .lzma files
  print("\n📦 Step 1: Extracting .lzma files...")
  
  target_folder = process_local_lzma_files(
    source_folder=source_folder
  )
  
  # Step 2: Load data from extracted files
  print(f"\n📊 Step 2: Loading data from {target_folder}...")
  
  # Find the appropriate subfolder for the sensor
  sensor_folders = {
    'eeg': ['EEG2', 'EEG'],
    'imu': ['IMU2', 'IMU'],
    'ppg': ['PPG2', 'PPG'],
    'hr': ['HR'],
    'spo2': ['SPO2']
  }
  
  sensor_subfolder = None
  for folder in sensor_folders.get(sensor, []):
    potential_path = os.path.join(target_folder, folder)
    if os.path.exists(potential_path):
      sensor_subfolder = potential_path
      break
  
  if sensor_subfolder is None:
    raise FileNotFoundError(f"Could not find appropriate folder for sensor '{sensor}' in {target_folder}")
  
  print(f"📂 Using sensor subfolder: {sensor_subfolder}")
  
  # Load data using the existing function

  result = load_array_from_folder(
    local_folder=sensor_subfolder,
    sensor=sensor,
    is_return_timestamp=True,  # Always return timestamp
    verbose=True,
    return_file_start_times=False
  )
  
  print(f"✅ Workflow completed successfully!")
  if isinstance(result, tuple) and len(result) > 0:
    if hasattr(result[0], 'shape'):
      print(f"📊 Data shape: {result[0].shape}")
  
  # Always return (data_array, start_time, target_folder)
  return result[0], result[1], target_folder